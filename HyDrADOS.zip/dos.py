from time import sleep
import os
import keyboard
keyboard.press("F11")
print("HydraDOS ver 0.1")
print("=============WELCOME==========")
for x in range(0,10):
    print("[                            ]")
print("==============================")
while 1:
    a = input(os.getcwd() + ":")
    os.system(a)
    
