import requests
while 1==1:
    url = input("Enter server ip, or domain:")
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
    requests.get("https://"+url)
