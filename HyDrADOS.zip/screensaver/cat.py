from tkinter import *
import time
import os
import keyboard
tk =Tk()
def ex():
    tk.destroy()
tk.attributes("-fullscreen",True)
tk.attributes("-topmost",True)
keyboard.add_hotkey('esc',lambda: ex())
tk.configure(background='black')
a = tk.winfo_screenwidth() + 10
b= tk.winfo_screenheight() + 10
c =Canvas(tk,width=a,height=b,bg="black")
img=PhotoImage(file="kiska2.gif")
df = c.create_image(0,0,image=img,anchor="nw")
c.config(cursor="none")
c.pack()
def moveimg():
    for x in range(0,100):
        time.sleep(0.0001)
        c.move(df,1,1)
        c.update()
    for x in range(0,100):
        time.sleep(0.0001)
        c.move(df,-1,1)
        c.update()
    for x in range(0,100):
        time.sleep(0.0001)
        c.move(df,1,-1)
        c.update()
while 1:
    moveimg()
tk.mainloop()

