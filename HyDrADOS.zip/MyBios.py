from selectmenu import SelectMenu
import os
menu = SelectMenu()
def safe():
    pass
def data():
    pass
def end():
    os.system("python dos.py")
def win():
    pass
a = menu.add_choices(
["SAFE MODE", "WIPE DATA", "REBOOT","WIN93"])
result = menu.select("Welcome to BIOS ver 1.1!")
input()
if (a=="SAFE MODE"):
    safe()
elif (a=="WIPE DATA"):
    data()
elif (a=="REBOOT"):
    end()
else:
    win()
